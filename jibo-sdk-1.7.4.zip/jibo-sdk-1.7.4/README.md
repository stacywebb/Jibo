The Jibo SDK is undergoing revision and will return! Visit https://developers.jibo.com and sign up to stay in the loop about SDK updates.
