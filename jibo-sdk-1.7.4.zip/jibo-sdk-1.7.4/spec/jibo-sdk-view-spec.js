'use babel';

import JiboSdkView from '../lib/jibo-sdk-view';

describe('JiboSdkView', () => {
  it('has one valid test', () => {
    expect('life').toBe('easy');
  });
});
