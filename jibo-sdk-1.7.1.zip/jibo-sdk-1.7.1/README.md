The Jibo Software Developer Kit (SDK) gives developers an easy way to build Jibo Skills (robot applications). The Jibo SDK includes animation and behavior editors and gives you access to Jibo's motors, speech technology, facial recognition and tracking, touch input technology, and more.

Click [here](http://developer.jibo.com) for Jibo SDK documentation.

![Jibo README gif](http://jiborobot.github.io/jibo-sdk/README.gif)
